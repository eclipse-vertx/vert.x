var tu = require('test_utils.js')
var vertx = require('vertx.js')

// If it runs the test is complete
tu.testComplete();