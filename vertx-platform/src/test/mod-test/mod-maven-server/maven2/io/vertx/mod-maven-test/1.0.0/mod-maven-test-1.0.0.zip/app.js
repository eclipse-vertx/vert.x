load('test_utils.js')
load('vertx.js')

var tu = new TestUtils();

// If it runs the test is complete
tu.testComplete();