load('vertx.js')

console.log("barmod loaded");

function vertxStop() {
  console.log("barmod unloaded");
}
