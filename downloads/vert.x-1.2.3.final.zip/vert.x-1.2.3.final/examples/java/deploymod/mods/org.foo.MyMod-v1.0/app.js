load("vertx.js")

console.log("in MyMod!")
console.log("some-var is " + vertx.config['some-var'])
