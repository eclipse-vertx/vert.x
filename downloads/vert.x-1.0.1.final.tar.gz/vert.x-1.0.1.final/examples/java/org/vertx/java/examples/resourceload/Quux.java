package org.vertx.java.examples.resourceload;

/**
 *
 * This gets built into its own jar which is loaded in the example
 *
 * @author <a href="http://tfox.org">Tim Fox</a>
 */
public class Quux {
  public int wibble() {
    return 23;
  }
}
