package com.acme;

import java.util.Date;

public class OtherClass {
  public Date date() {
    return new Date();
  }
}